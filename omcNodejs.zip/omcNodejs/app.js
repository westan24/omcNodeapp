require('oracle-apm')
const express = require('express');
const path = require('path');
const exphbs  = require('express-handlebars');
const methodOverride = require('method-override');
const flash = require('connect-flash');
const session = require('express-session');
const bodyParser = require('body-parser');
const passport = require('passport');
const mongoose = require('mongoose');

const app = express();

//It's necessary for Cross Domain of AJAX
var cors = require( 'cors' );
app.use( cors() );

//Load routes
const ideas = require('./routes/ideas');
const users = require('./routes/users');

//Load Weather Model 
require('./models/Weather');
const Weather = mongoose.model('Weather');

// Passport Config -> Authentication
require('./config/passport')(passport);

// DB Config
const db = require('./config/database');

// Map global promise - get rid of warning
mongoose.Promise = global.Promise;

// Connect to mongoose
mongoose.connect(db.mongoURI, {
  useMongoClient: true,
})
  .then(() => console.log('MongoDB Connected...'))
  .catch(err => console.log(err));

// Handlebars Middleware
app.engine('handlebars', exphbs({
  defaultLayout: 'main'
}));
app.set('view engine', 'handlebars');

// Body parser middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Static folder
app.use(express.static(path.join(__dirname, 'public')));

// Method override middleware
app.use(methodOverride('_method'));

// Express session midleware
app.use(session({
  secret: 'secret',
  resave: true,
  saveUninitialized: true
}));

// Passport middleware
app.use(passport.initialize());
app.use(passport.session());

app.use(flash());


// Global variables
app.use(function(req, res, next){
  res.locals.success_msg = req.flash('success_msg');
  res.locals.error_msg = req.flash('error_msg');
  res.locals.error = req.flash('error');
  res.locals.user = req.user || null;
  next();
});

// Index Route
app.get('/', (req, res) => {

  //--------------------------------------
  //Call Weather REST API 
  var request = require("request");
  var options = {
    method: 'GET',
    url: 'http://weather.livedoor.com/forecast/webservice/json/v1?city=130010'
  };

  request(options, function (error, response, body) {
    if (error) throw new Error(error);
    var json = body;
    //Parse & Insert Response body
    obj = JSON.parse(json);
   
    //Write tommorow's weather into DB
      if (obj.forecasts[1].temperature.min.celsius == null) {
        obj.forecasts[1].temperature.min.celsius  = "?";
      }
      if (obj.forecasts[1].temperature.max.celsius == null) {
        obj.forecasts[1].temperature.max.celsius  = "?";
      }
      
      const newUser = {
        city: obj.location.city,
        dateLabel: obj.forecasts[1].dateLabel,
        telop: obj.forecasts[1].telop,
        date: obj.forecasts[1].date,
        temperature_min: obj.forecasts[1].temperature.min.celsius,
        temperature_max: obj.forecasts[1].temperature.max.celsius,
        description: obj.description.text
        }  

      Weather(newUser)
      .save()
      .then(Weather => {
        // Success
    }) 
    
    //Rendering index
    const title = 'Welcome to OMC';      
    res.render('index', {
      title: title,
      city: newUser.city,
      dateLabel: newUser.dateLabel,
      telop: newUser.telop,
      date: newUser.date,
      temperature_min: newUser.temperature_min,
      temperature_max: newUser.temperature_max,
      description: newUser.description   
    });
  });
  //--------------------------------------
});

app.get('/about', (req, res) => {
  res.render('about');
});


// Call Talk API
app.get('/about/:message', (req, res) => {  
  console.log(req.params.message)
  var request = require("request");
  var options = {
    method: 'POST',
    headers: {
      "Content-type": "application/json;charset=utf-8",
    },
    url: 'https://api.a3rt.recruit-tech.co.jp/talk/v1/smalltalk',
    form: {
            "apikey" : "DZZFaHXULTQjaxHmxxX7rbCndpl8WTHj",
            "query" : req.params.message
          }
  };

  request(options, function (error, response,body) {    
    //Get Reply from Response
    var obj = JSON.parse(body)
    var reply = JSON.stringify(obj.results[0].reply)
    console.log(reply)  
    res.send(reply);

    //res.render('about', {
    //  reply:reply
    // });
  });
});


// Use routes
app.use('/ideas', ideas);
app.use('/users', users);

const port = process.env.PORT || 8080;

app.listen(port, () =>{
  console.log(`Server started on port ${port}`);
});