if(process.env.NODE_ENV === 'production'){
  module.exports = {mongoURI: 'mongodb://mongodb/vidjot-dev'}
} else {
  module.exports = {mongoURI: 'mongodb://localhost/vidjot-dev'}
}