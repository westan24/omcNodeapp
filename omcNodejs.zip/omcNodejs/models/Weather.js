const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Create Schema
const UserSchema = new Schema({
  city:{
    type: String,
    required: true
  },
  dateLabel:{
    type: String,
    required: true
  },
  telop:{
    type: String,
    required: true
  },
  date:{
    type: String,
    required: true
  },
  temperature_min:{
    type: String,
    required: true
  },
  temperature_max:{
    type: String,
    required: true
  },
  description:{
    type: String,
    required: true
  }
});

mongoose.model('Weather', UserSchema);


